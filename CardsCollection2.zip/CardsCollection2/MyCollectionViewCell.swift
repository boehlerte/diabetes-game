//
//  MyCollectionViewCell.swift
//  CardsCollection2
//
//  Created by Benjamin Tanger Eggleston on 4/5/17.
//  Copyright © 2017 Benjamin Tanger Eggleston. All rights reserved.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var myImageView: UIImageView!
       
}
